﻿using System.Text;
using Tamagochi.BL;
using Tamagochi.Modules;

namespace Tamagochi;

class Program
{
    public static void Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;

        /*Cat cat = InputData();
        FileManager.SaveOne(cat);*/

        Menu menu = new Menu();
        while (true)
        {
            switch (menu.Run())
            {
                case 0:
                    InputData();
                    break;
                case 1:
                    Console.WriteLine("2");
                    break;
                case 2:
                    Console.WriteLine("3");
                    break;
                case 3:
                    Console.WriteLine("4");
                    break;
                case 4:
                    Console.Clear();
                    Environment.Exit(0);
                    break;
            }
        }
    }
    public static Cat InputData()
    {
        Cat cat = new Cat();
        cat.Name = UserInput.InputString("Введи Имя");
        cat.Age = UserInput.InputInteger("Введи возраст");
        Random random = new Random();
        cat.Health = random.Next(20, 81);
        cat.Mood = random.Next(20, 81);
        cat.Satiety = random.Next(20, 81);
        cat.Level = (cat.Health + cat.Mood + cat.Satiety) / 3;
        return cat;
    }
}