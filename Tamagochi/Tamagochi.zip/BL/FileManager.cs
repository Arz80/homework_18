﻿using System.Text.Json;
using Tamagochi.Interfaces;
using Tamagochi.Modules;

namespace Tamagochi.BL;

static class FileManager
{
    private static string fileName = "Cats.json";
    public static void SaveAll()
    {
        // TODO: Отсортировать и записать в файл
    }
    public static void SaveOne(Cat cat)
    {
        string serCat = JsonSerializer.Serialize<Cat>(cat);
        File.AppendAllText(fileName, serCat + "\n");
            
    }
    public static List<Cat> ReadAll()
    {
        string[] allCatsString = File.ReadAllLines(fileName);
        List<Cat> allCats = new List<Cat>();
        foreach (string cat in allCatsString)
        {
            Cat? catDesir = JsonSerializer.Deserialize<Cat>(cat);
            if(catDesir != null)
            {
                allCats.Add(catDesir);
            }
        }
        return allCats;
    }
    public static void ReadOne()
    {
        // TODO: Прочитать из файла
    }
    public static void Sorting()
    {
        // TODO: Показать таблицу на экране
    }
}
