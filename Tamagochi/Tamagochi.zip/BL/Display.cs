﻿using Tamagochi.Modules;

namespace Tamagochi.BL;

static class Display
{
    public static void Show(List<Cat> cats)
    {
        foreach (Cat cat in cats)
        {
            Console.WriteLine(cat.Name);
        }
    }
}
